LLMWARE MODEL HQ API SERVER CLIENT SDK ENABLEMENT KIT - v10100+ - June 2025

Contents
-- 	api_service_catalog.py 	- 	list of supported api calls
-- 	llmware_client_sdk.py 	- 	python methods that implement the api calls
-- 	hello_world.py		    -	start here to confirm that server is working as expected
--  examples.py             -   a few more examples, including agents and basic control api
--	test_file_models.py	    -	runs through a series of model inferencing calls
--	test_file_admin.py	    -	runs through a series of admin API calls
--	test_file_rag.py	    -	runs through a series of rag (library and embedding) API calls
--	/sample_files		    -	includes sample files used in the test files
--	requirements.txt	    -	python requirements for the client library
