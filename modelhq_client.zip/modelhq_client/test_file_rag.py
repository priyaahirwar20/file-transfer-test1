
""" Tests for RAG APIs

    ** Background on Library **

    -- Foundation of the RAG APIs is the concept of a Library, which is the organizing construct
        for collections of documents and unstructured information

    -- Libraries encapsulate a lot of low level functionality and expose several high-level APIs
       that do a lot of work, e.g. :

       -- create library
       -- add documents - parse, text chunk and index raw document files to DB
       -- install embedding - create a vector embedding space for the library
       -- semantic query - query the semantic embedding space

        -- Most of the RAG methods operate on a Library

    ** Use of both primary Text Collection DB and Vector DB **

    -- When "add documents" is executed, the parsed text chunks are indexed in a 'text collection'
       primary database, either Mongo or Postgres, and added to the "library"

    -- When "install embedding" is executed, the text chunks from the primary database are used to
       create vector embeddings, which are then stored in a vector specific DB - options include:
       Milvus, Qdrant, PG Vector (Postgres), Neo4J or Redis

    ** Sample Materials Included **

    -- these tests use several sample materials
    -- '/sample_files' - Agreements & UN-Resolutions-500
    -- there are async steps and options - and it can take a few minutes to create
    -- depending upon the size of the library
    -- best to run each test independently and sequentially

"""

from llmware_client_sdk import LLMWareClient

my_endpoint = "http://44.198.29.51:8088"

client = LLMWareClient(api_endpoint=my_endpoint)


def get_library_card_example(lib_name=None, db="mongo", trusted_key="blue-harissa"):

    """ Identify existing libraries on the server. """

    print("\nget_library_card example\n")

    response = client.get_library_card(library_name=lib_name,trusted_key=trusted_key,db=db)

    print("response: ", response)

    if "library_cards" in response:
        if len(response["library_cards"]) > 0:
            for i, card in enumerate(response["library_cards"]):
                print("library found - ", i, card)

    return response


def semantic_query_example(lib_name, input_query, db="mongo",
                           vector_db="milvus", embedding_model=None,trusted_key="blue-harissa"):

    """ Execute a semantic search query on an existing library collection - runs a vector embedding
    similarity search on the associated vector DB. """

    print("\nsemantic query example\n")

    response = client.semantic_query(lib_name,input_query,trusted_key=trusted_key,build_context=True,
                                     db=db, vector_db=vector_db)

    print("response: ", response)

    for keys in response:
        print("keys found - ", keys)

    if "context" in response:
        print("\noutput context - ", response["context"])

    return response


def library_inference_example(library_name=None, question=None,
                              model_name="llama-3.2-1b-instruct-ov"):

    """ Executes a generative RAG inference from a natural language question, by selecting the
    relevant information from a pre-created library (and vector embeddings) on the server.
    """

    if library_name and question:
        output = client.library_inference(lib_name, question, model_name=model_name)
        print("\n\nresponse: ", output)

    else:
        print(f"\ncould not find both library - {library_name} and/or question - {question}")
        output = {}

    return output


def create_library_example(library_name,trusted_key="blue-harissa", db="sqlite"):

    print("\ncreate library example\n")

    response = client.create_new_library(library_name=library_name,trusted_key=trusted_key,db=db)

    print("response: ", response)

    return response


def add_files_example(library_name, file_path, trusted_key="blue-harissa", db="sqlite", use_async=False, **kwargs):

    print("\nadd files example\n")
    response = client.add_files(library_name,file_path,trusted_key=trusted_key, db=db, use_async=use_async, **kwargs)

    print("response: ", response)

    return response


def query_example(library_name, user_query, trusted_key="blue-harissa",result_count=20, db="sqlite"):

    print("\nquery example\n")
    response = client.query(library_name,user_query,trusted_key=trusted_key,result_count=result_count,
                            db=db)

    print("response: ", response)

    if "results" in response:
        if isinstance(response["results"], list):
            for i, result in enumerate(response["results"]):
                print("result: ", i, result)

    return response


def get_document_list_example(lib_name="", **kwargs):

    print("\nget_document_list example\n")

    response = client.get_document_list(library_name=lib_name, **kwargs)

    print("response: ", response)

    return response


def get_document_text_example(lib_name="", doc_id="", doc_fn="", **kwargs):

    print("\nget_document_text example\n")

    response = client.get_document_text(library_name=lib_name,doc_id=doc_id,doc_fn=doc_fn, **kwargs)

    print("response: ", response)

    response_keys = ["document_text", "query_results"]

    for key in response_keys:
        if key in response:
            print(f"\n{key} - {response[key]}")

    return response


def install_embedding_example(lib_name, trusted_key="blue-harissa", db="sqlite",vector_db="milvus",
                              use_async=False, batch_size=500,embedding_model="industry-bert-contracts"):

    print("\ninstall embedding example\n")
    response = client.install_embedding(lib_name,trusted_key=trusted_key, db=db,vector_db=vector_db,
                                        batch_size=batch_size, use_async=use_async,
                                        embedding_model=embedding_model)

    print("response: ", response)

    return response


def test1_build_library(lib1="agreements_123",
                        lib2="un_resolutions_123",
                        db="mongo"):

    """ Test1:  build two libraries - one small and one medium size - add files - run a few test text queries

    Note: this test does not use the vector db - it is only parsing and indexing and then checking for
    text-based queries.   Once the libraries are created, then embeddings are generated in test2.
    """

    # build first library
    print(f"\n\nbuilding first library - {lib1}\n\n")

    create_library_example(lib1,db=db)

    # use sample_files link provided - this maps to the 'agreements' folder with ~15 employment agreements
    path_to_agreements_sample_files = ".\\sample_files\\Agreements"

    add_files_example(lib1, path_to_agreements_sample_files,db=db)
    query_example(lib1, "salary", db=db)
    get_library_card_example(lib_name=None, db=db)

    # build second library
    print(f"\n\nbuilding second library - {lib2}\n\n")

    path_to_un_resolutions_sample_files = ".\\sample_files\\UN-Resolutions-500"

    add_files_example(lib2, path_to_un_resolutions_sample_files, db=db,
                      chunk_size=800,max_chunk_size=1200,get_images=False,use_async=False)

    query_example(lib2, "africa",db=db)
    get_library_card_example(lib_name=None, db=db)

    print("\n\nretrieve specific docs/text info\n\n")

    get_document_list_example(lib_name=lib1,db=db)

    get_document_text_example(lib_name=lib2,doc_fn="N1931839.pdf",db=db)


def test2_install_embeddings (lib="un_resolutions", db="mongo", vector_db="milvus",
                              embedding_model="industry-bert-contracts"):

    """ After running test1, this test will generate embeddings on one of the libraries created. """

    install_embedding_example(lib,db=db,vector_db=vector_db,batch_size=500,use_async=True,
                              embedding_model=embedding_model)
    return True


if __name__ == "__main__":

    """ Run each test separately, as embedding is run async. """

    # ** check available database resources on the server **

    db_info = client.get_db_info()

    print("\navailable db resources: ", db_info)

    # **  check any libraries already created on the server **

    db = "mongo"
    vector_db = "milvus"

    response = client.get_library_card(db=db)

    for i, library in enumerate(response["library_cards"]):
        print(f"libraries on {db} - {i} - {library}")

    #  ** run a test 'rag' inference on one of the existing libraries **
    #  -- expect that "un_resolutions_300_mg" is one of the libraries already created
    #  -- this library is created from the ./sample_files/UN-Resolutions-500

    lib_name = "un_resolutions_300_mg"
    question = "Summarize the key resolutions related to Ukraine."
    model_name = "llama-3.2-1b-instruct-ov"

    library_inference_example(library_name=lib_name,
                              question = question,
                              model_name=model_name)

    #  ** run a semantic search only - and get search results back **

    queries = [
        "What are the sustainability conditions impacting women in Africa?",
        "What are the main Ukraine provisions?",
        "What is the state of global warming?",
        "How is poverty being handled?"
    ]

    for x in queries:
        semantic_query_example(lib_name, x, vector_db=vector_db, db=db)

    #   ** build library **
    test1_build_library(lib1="agreements_050525", lib2="un_resolutions_050525", db="mongo")

    #   ** add semantic embeddings ***
    #   -- uncomment to install embeddings on test library
    # test2_install_embeddings(lib="test1", db="mongo", vector_db=vector_db,
    #                         embedding_model="industry-bert-contracts-ov")
