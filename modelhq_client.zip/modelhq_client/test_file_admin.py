
""" Tests for Admin / Api Server utility APIs. """

from llmware_client_sdk import LLMWareClient

api_endpoint = "http://44.198.29.51:8088"

client = LLMWareClient(api_endpoint=api_endpoint)


def ping_example():

    print("\nping test example\n")

    response = client.ping()

    print("response: ", response)

    return response


def list_models():

    """ Get a list of models in the catalog.   Invoke any model by using its name.

    Please note that this is the complete list available to this machine, and not a list
    of the currently cached models or actively loaded models.

    To get a current view of the loaded models in memory, use sys_info API.
    """

    # what models are available?
    model_list = client.list_all_models()
    print("model list: ", model_list)
    for i, mod in enumerate(model_list["response"]):
        print("model: ", i, mod)

    return model_list


def model_lookup_example(model_name, **kwargs):

    print("\nmodel lookup example\n")

    response = client.model_lookup(model_name, **kwargs)

    print("response: ", response)

    return response


def get_api_catalog_example(trusted_key="blue-harissa"):

    print("\napi catalog example\n")

    response = client.get_api_catalog(trusted_key=trusted_key)

    print("response: ", response)
    if "response" in response:
        if isinstance(response["response"],list):
            for i, entry in enumerate(response["response"]):
                print(f"api - {i} - {entry}")

    return response


def get_system_info(**kwargs):

    print("\napi system info example\n")

    response = client.system_info(**kwargs)

    print("response: ", response)

    return response


def check_db_resources():

    print("\ncheck available db resources\n")

    db_info = client.get_db_info()

    print("db info - ", db_info)
    print("\n")

    return db_info


def model_load_example(model_name, **kwargs):

    print("\nmodel load test example\n")

    response = client.model_load(model_name, **kwargs)

    print("response: ", response)

    return response


def model_unload_example(model_name, **kwargs):

    print("\nmodel unload test example\n")

    response = client.model_unload(model_name, **kwargs)

    print("response: ", response)

    return response


if __name__ == "__main__":
    ping_example()
    get_api_catalog_example()
    model_lookup_example("phi-3-ov")
    get_system_info()
    check_db_resources()
    list_models()


