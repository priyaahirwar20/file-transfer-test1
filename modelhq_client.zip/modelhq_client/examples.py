
""" A few examples to get started. See the documentation for more, or look at the api_service_catalog.py
    file included with these materials which provides direct overview of each of the supported APIs. """

import os
from modelhq_client import LLMWareClient, get_server_details, stop_server, get_url_string

# endpoint can usually be determined automatically using get_url_string()
# alternatively, it will be displayed at the time of launching the backend server
# it will usually correspond explicitly to:  "http://localhost:8088" and/or external IP of device

# my_endpoint = "http://localhost:8088"

my_endpoint = get_url_string()
print("auto detected get_url_string - ", my_endpoint)

client = LLMWareClient(api_endpoint=my_endpoint)

model = "llama-3.2-1b-instruct-ov"
prompt = "Who was the U.S. president in 2010?"

response = client.inference(model=model, prompt=prompt)

print("response: ", response)

# show all agents available on the background server
agent_response = client.get_all_agents()
for i, agent in enumerate(agent_response["response"]):
    print("agents available: ", i, agent)

# run agent process - uses sample file included in the development kit
# alternatively, you could pass another file, or direct text string, e.g., text = "..."
process_name = "intake_processing"
fp = os.path.abspath(".\\sample_files\\customer_transcript_1.txt")
text = open(fp, "r").read()

response = client.run_agent(process_name=process_name, text=text, trusted_key="")
print("run_agent intake_processing: ", response)

# get system info
x = client.system_info()
print("system info: ", x)

# unload model from server memory
client.model_unload(model)

# get details about the backend process
details = get_server_details()
print("server details: ", details)

# uncomment to stop the backend server
stop_server()

