
""" Master list of implemented development APIs with details about the endpoint -

    1.  Models - main Inference & Specialized inference methods
    2.  RAG - library, embedding and retrieval methods
    3.  Agent - execute custom agent workflow process
    4.  Admin/Utility - core admin functions for the API Server

"""


api_catalog = [

    # Main Inferencing Methods

    # ** stream ** is the core endpoint for generating a streaming inference response from a selected model

    {"api_name": "stream",
     "methods": ["POST"],
     "endpoint": "/stream/",
     "function": "stream",
     "params": [
            # required
            "model_name", "prompt",
            # optional
            "max_output", "temperature", "sample", "context", "api_key", "trusted_key"
              ],
     "response": ["llm_response"],
     "category": "models",
     "timeout": 60},

    # ** inference ** is the core endpoint for generating a complete inference response from a selected model
    # the response will be the complete generation from the model

    {"api_name": "inference",
     "methods": ["POST"],
     "endpoint": "/inference/",
     "function": "inference",
     "params": [
                # required
                "prompt","model_name",
                # optional
                "max_output", "temperature","sample","api_key","context",
                 "params","fx", "trusted_key"
                ],
     "response": ["llm_response"],
     "category": "models",
     "timeout": 60},

    # ** function_call** - executes a specialized function call with SLIM model

    {"api_name": "function_call",
     "methods": ["POST"],
     "endpoint": "/function_call/",
     "function": "fx",
     "params": [
                # required
                "model_name", "context",
                # optional
                "prompt", "params", "function", "api_key", "get_logits",
                "max_output", "temperature","sample", "trusted_key"
                ],
     "response": ["llm_response"],
     "category": "models",
     "timeout": 60},

    # ** sentiment ** - executes a slim-sentiment function call

    {"api_name": "sentiment",
     "methods": ["POST"],
     "endpoint": "/sentiment/",
     "function": "sentiment",
     "params": [
                # required
                "context",
                # optional
                "model_name", "get_logits", "max_output", "temperature", "sample", "trusted_key"],
     "response": ["llm_response"],
     "category": "models",
     "timeout": 60},

    # ** extract ** - executes a slim extract function call

    {"api_name": "extract",
     "methods": ["POST"],
     "endpoint": "/extract/",
     "function": "extract",
     "params": [
              # required
              "context", "extract_keys",
              # optional
              "get_logits", "max_output", "temperature", "sample", "trusted_key"],
     "response": ["llm_response"],
     "category": "models",
     "timeout": 60},

    # ** vision ** - executes a vision model inference

    {"api_name": "vision",
     "methods": ["POST"],
     "endpoint": "/vision/",
     "function": "vision",
     "params": [
               # required
               "uploaded_files","prompt",
               # optional
               "max_output", "model_name", "temperature", "sample", "trusted_key"],
     "response": ["llm_response"],
     "category": "models",
     "timeout": 360},

    # ** vision_stream ** - generates a streaming inference response from vision model

    {"api_name": "vision_stream",
     "methods": ["POST"],
     "endpoint": "/vision_stream/",
     "function": "vision_stream",
     "params": [
               # required
               "uploaded_files", "model_name", "prompt",
               # optional
               "max_output", "temperature", "sample", "trusted_key"
               ],
     "response": ["llm_response"],
     "category": "models",
     "timeout": 360},

    # ** rank ** - executes a semantic similarity with reranker model

    {"api_name": "rank",
     "methods": ["POST"],
     "endpoint": "/rank/",
     "function": "rank",
     "params": [
               # required
               "query", "documents",
               # optional
               "model_name", "text_chunk_size", "trusted_key"
               ],

     "response": ["llm_response"],
     "category": "models",
     "timeout": 60},

    # ** classify ** - executes a specific classifier inference (used primarily for safety/controls currently)

    {"api_name": "classify",
     "methods": ["POST"],
     "endpoint": "/classify/",
     "function": "classify",
     "params": [
               # required
               "model_name", "context",
               # optional
              "text_chunk_size", "trusted_key"
               ],
     "response": ["llm_response"],
     "category": "models",
     "timeout": 60},

   # ** embedding ** - executes an embedding inference

   {"api_name": "embedding",
     "methods": ["POST"],
     "endpoint": "/embedding/",
     "function": "embedding",
     "params": [
               # required
               "model_name", "context",
               # optional
               "text_chunk_size", "trusted_key"
               ],
     "response": ["embeddings"],
     "category": "models",
     "timeout": 60},

    # ** document_inference ** - specialized inference to ask set of questions to an upload document file
    # this single api combines a useful pattern consisting of several steps:
    #   -- parse and text chunk the document
    #   -- use semantic reranker to find the most relevant parts of the document based on the user query
    #   -- assemble a context passage of the most relevant document pieces
    #   -- assemble the prompt with the context passage and query
    #   -- prompt the llm and get the llm to answer the question

    {"api_name": "document_inference",
     "methods": ["POST"],
     "endpoint": "/document_inference/",
     "function": "document_inference",
     "params": [
                # required
                "question", "uploaded_document",
                # optional
                "model_name", "text_chunk_size",
                "tables_only", "use_top_n_context", "trusted_key"
               ],
     "response": ["response"],
     "category": "rag",
     "timeout": 60},

    # ** library_inference ** - specialized rag inference that ranks entries from a library on API server and generates response
    # based on the retrieved entries

    {"api_name": "library_inference",
     "methods": ["POST"],
     "endpoint": "/library_inference/",
     "function": "library_inference",
     "params": [
               # required
               "question", "library_name", "model_name",
               # optional
               "use_top_n_context", "trusted_key"
               ],
     "response": ["response"],
     "category": "rag",
     "timeout": 60},

    # ** list_all_models ** - lists all of the models available on the server

    {"api_name": "list_all_models",
      "methods": ["POST"],
      "endpoint": "/list_all_models/",
      "function": "list_all_models",
      "params": ["trusted_key"],
      "response": ["response"],
      "category": "models",
      "timeout": 3},

     # ** system_info ** - returns key information about the system and server

     {"api_name": "system_info",
      "methods": ["POST"],
      "endpoint": "/system_info/",
      "function": "system_info",
      "params": ["trusted_key"],
      "response": ["response"],
      "category": "models",
      "timeout": 3},

    # ** model_lookup ** - returns model card information about a selected model

    {"api_name": "model_lookup",
     "methods": ["POST"],
     "endpoint": "/model_lookup/",
     "function": "model_lookup",
     "params": [
                # required
                "model_name",
                # optional
                "trusted_key"
                ],
     "response": ["response"],
     "category": "models",
     "timeout": 3},

    # ** model_load ** - loads a selected model into memory of the server (admin)

    {"api_name": "model_load",
     "methods": ["POST"],
     "endpoint": "/model_load/",
     "function": "model_load",
     "params": [
               # required
               "model_name",
               # optional
               "trusted_key", "sample", "temperature", "max_output"
               ],
     "response": ["response"],
     "category": "models",
     "timeout": 20},

    # ** model_unload ** - unloads a selected model from the memory of the server (admin)

    {"api_name": "model_unload",
     "methods": ["POST"],
     "endpoint": "/model_unload/",
     "function": "model_unload",
     "params": [
                # required
                "model_name",
                # optional
                "trusted_key"
                ],
     "response": ["response"],
     "category": "models",
     "timeout": 20},

   # ** ping ** - pings the server to confirm that the connection is active

   {"api_name": "ping",
     "methods": ["POST"],
     "endpoint": "/ping/",
     "module": "api_server.endpoints_admin",
     "function": "ping",
     "params": ["trusted_key"],
     "response": ["ping"],
     "category": "admin",
     "timeout": 1},

   # ** server_stop ** - WIP / SKIP

   {"api_name": "server_stop",
    "methods": ["POST"],
    "endpoint": "/server_stop/",
    "function": "server_stop",
    "params": ["trusted_key"],
    "response": ["status"],
    "category": "server",
    "timeout": 10},

    # ** get_api_catalog ** - returns a list of the APIs supported on the server with description/details

    {"api_name": "get_api_catalog",
     "methods": ["POST"],
     "endpoint": "/library/get_api_catalog/",
     "module": "api_server.endpoints_admin",
     "function": "get_api_catalog",
     "params": [
            # optional
            "trusted_key"
            ],
     "response": ["response"],
     "category": "admin",
     "timeout": 3},

    # ** document_batch_analysis ** - designed for batch analysis with multiple documents and questions
    # -- similar to the document_inference, but supports multiple questions and files

    {"api_name": "document_batch_analysis",
     "methods": ["POST"],
     "endpoint": "/document_batch_analysis/",
     "module": "api_server.endpoints_models",
     "function": "document_batch_analysis",
     "params": [
                # required
                "question_list", "uploaded_files",
                # optional
                "trusted_key", "reranker", "rag"
                ],
     "response": ["analysis_report"],
     "category": "models",
     "timeout": 60},

    # ** create_new_library ** - create a new library (available only on Model HQ API Server on Linux)

    {"api_name": "create_new_library",
     "methods": ["POST"],
     "endpoint": "/library/create_new_library/",
     "module": "api_server.endpoints_library",
     "function": "create_new_library",
     "params": [
            # required
            "library_name", "account_name", "db",
            # optional
            "trusted_key"],
     "response": ["response"],
     "category": "library",
     "timeout": 5},

    # ** add_files ** - used as the first step after create_new_library to add files and build up the library content -
    # (available only on Model HQ API Server on Linux)

    {"api_name": "add_files",
     "methods": ["POST"],
     "endpoint": "/library/add_files/",
     "module": "api_server.endpoints_library",
     "function": "add_files_to_library",
     "params": [
                # required
                "uploaded_files", "library_name", "account_name", "db",
                # optional
                "trusted_key",
                "chunk_size", "get_images", "get_tables", "smart_chunking", "max_chunk_size",
                "table_strategy"
                ],
     "response": ["response"],
     "category": "library",
     "timeout": 360},

    # ** add_files_async ** - used as the first step after create_new_library to add files
    # and build up the library content - (available only on Model HQ API Server on Linux)

    {"api_name": "add_files_async",
     "methods": ["POST"],
     "endpoint": "/library/add_files_async/",
     "module": "api_server.endpoints_library",
     "function": "add_files_to_library_async",
     "params": [
                # required
                "uploaded_files", "library_name", "account_name", "db",
                # optional
                "trusted_key",
                "chunk_size", "get_images", "get_tables", "smart_chunking", "max_chunk_size",
                "table_strategy"],
     "response": ["response"],
     "category": "library",
     "timeout": 20},

    # ** query ** - execute query against a library (available only on Model HQ API Server)

    {"api_name": "query",
     "methods": ["POST"],
     "endpoint": "/library/query/",
     "module": "api_server.endpoints_library",
     "function": "query",
     "params": [
                # required
                "library_name", "account_name",
                # optional
                "user_query", "result_count", "db", "trusted_key"],
     "response": ["response"],
     "category": "library",
     "timeout": 5},

    # ** get_library_card ** - returns the metadata library card for a selected library
    # (available only on Model HQ API Server)

    {"api_name": "get_library_card",
     "methods": ["POST"],
     "endpoint": "/library/get_library_card/",
     "module": "api_server.endpoints_library",
     "function": "get_library_card",
     "params": [
                # required
                "library_name", "account_name", "db",
                # optional
                "trusted_key"
                ],
     "response": ["response"],
     "category": "library",
     "timeout": 5},

    # ** semantic_query ** - runs a semantic query against a library
    # (available only on Model HQ API Server)

    {"api_name": "semantic_query",
     "methods": ["POST"],
     "endpoint": "/library/semantic_query/",
     "module": "api_server.endpoints_library",
     "function": "semantic_query",
     "params": [
                # required
                "library_name", "account_name", "user_query", "vector_db", "db", "embedding_model",
                # optional
                "result_count", "build_context", "trusted_key", "width_before", "width_after"
                ],
     "response": ["results", "context"],
     "category": "library",
     "timeout": 5},

    # ** install_embedding ** - applies an embedding model to a previously created library to build a
    # vector database for the library and enable semantic search
    # (available only on Model HQ API Server)

    {"api_name": "install_embedding",
     "methods": ["POST"],
     "endpoint": "/library/install_embedding/",
     "module": "api_server.endpoints_library",
     "function": "install_embedding",
     "params": [
                # required
                "library_name", "account_name", "model_name", "vector_db", "db",
                # optional
                "batch_size", "embedding_model", "trusted_key"
                ],
     "response": ["embedding_record"],
     "category": "library",
     "timeout": 360},

    # ** install_embedding_async ** - same as install_embedding but not blocking, runs process asynchronously

    {"api_name": "install_embedding_async",
     "methods": ["POST"],
     "endpoint": "/library/install_embedding_async/",
     "module": "api_server.endpoints_library",
     "function": "install_embedding_async",
     "params": [
                # required
                "library_name", "account_name", "model_name", "vector_db", "db",
                # optional
                "batch_size", "embedding_model", "trusted_key"
                ],
     "response": ["embedding_record"],
     "category": "library",
     "timeout": 10},

    # ** get_document_list ** - returns a list of all of the documents in a selected library
    # (only available on Model HQ API Server)

    {"api_name": "get_document_list",
     "methods": ["POST"],
     "endpoint": "/library/get_document_list/",
     "module": "api_server.endpoints_library",
     "function": "get_document_list",
     "params": [
                # required
                "library_name", "account_name", "db",
                # optional
                "trusted_key"
                ],
     "response": ["doc_id_list", "doc_fn_list"],
     "category": "library",
     "timeout": 20},

    # ** get_document_text ** - returns the text from a selected document in a selected library
    # (only available on Model HQ API Server)

    {"api_name": "get_document_text",
     "methods": ["POST"],
     "endpoint": "/library/get_document_text/",
     "module": "api_server.endpoints_library",
     "function": "get_document_text",
     "params": [
                # required
                "library_name", "account_name", "doc_id", "doc_fn", "db",
                # optional
               "trusted_key"
                ],
     "response": ["document_text", "query_results"],
     "category": "library",
     "timeout": 20},

   # DEPRECATED / REMOVING / SKIP FOR NOW

   {"api_name": "process_workflow",
    "methods": ["POST"],
    "endpoint": "/process_workflow/",
    "function": "process_workflow",
    "params": ["process_map", "trusted_key"],
    "response": ["report", "research", "safety_record", "response_list", "journal"],
    "category": "agents",
    "timeout": 60},

   # ** run_agent_process ** - executes selected agent process, if available on server

   {"api_name": "run_agent_process",
    "methods": ["POST"],
    "endpoint": "/run_agent_process/",
    "function": "run_agent_process",
    "params": ["process_name"],
    "response": ["agent_output"],
    "category": "agents",
    "timeout": 500},

    # ** lookup_agent ** - check if agent is available on server

    {"api_name": "lookup_agent",
     "methods": ["POST"],
     "endpoint": "/lookup_agent/",
     "function": "lookup_agent",
     "params": [
                # required
                "process_name",
                # optional
                "trusted_key"
                ],
     "response": ["agent_details"],
     "category": "agents",
     "timeout": 3},

    # ** download_agent ** - download agent from server to device

    {"api_name": "download_agent",
     "methods": ["POST"],
     "endpoint": "/download_agent/",
     "function": "download_agent",
     "params": [
                # required
                "process_name",
                # optional
                "trusted_key"
                ],
     "response": ["agent_zip"],
     "category": "agents",
     "timeout": 15},

    # ** get_all_agents ** - returns a list of all agents available on the server

    {"api_name": "get_all_agents",
     "methods": ["POST"],
     "endpoint": "/get_all_agents/",
     "function": "get_all_agents",
     "params": [
                # optional
                "trusted_key"
                ],
     "response": ["agent_list"],
     "category": "agents",
     "timeout": 5},

    # ** install_agent ** - installs an agent on the server

    {"api_name": "install_agent",
     "methods": ["POST"],
     "endpoint": "/install_agent/",
     "function": "install_agent",
     "params": [
                # required
                "process_zip",
                # optional
                "trusted_key"
                ],
     "response": ["agent_details"],
     "category": "agents",
     "timeout": 10},

    # ** install_bot ** - installs a bot on the server

    {"api_name": "install_bot",
     "methods": ["POST"],
     "endpoint": "/install_bot/",
     "function": "install_bot",
     "params": [
                # required
                "bot_zip",
                # optional
                "trusted_key"
                ],
     "response": ["bot_details"],
     "category": "agents",
     "timeout": 10},

    # ** download_bot ** - download a bot from server to device

    {"api_name": "download_bot",
     "methods": ["POST"],
     "endpoint": "/download_bot/",
     "function": "download_bot",
     "params": [
                # required
                "bot_name",
                # optional
                "trusted_key"
                ],
     "response": ["bot_zip"],
     "category": "agents",
     "timeout": 15},

    # ** get_all_bots ** - returns a list of all bots on the server/device

    {"api_name": "get_all_bots",
     "methods": ["POST"],
     "endpoint": "/get_all_bots/",
     "function": "get_all_bots",
     "params": [
                # optional
                "trusted_key"
                ],
     "response": ["bot_list"],
     "category": "agents",
     "timeout": 5},

    # ** lookup_bot ** - lookup a selected bot on server/device

    {"api_name": "lookup_bot",
     "methods": ["POST"],
     "endpoint": "/lookup_bot/",
     "function": "lookup_bot",
     "params": [
                # required
                "bot_name",
                # optional
                "trusted_key"
                ],
     "response": ["bot_details"],
     "category": "agents",
     "timeout": 3},

    # ** run_agent ** - runs an agent process on server/device

    {"api_name": "run_agent",
     "methods": ["POST"],
     "endpoint": "/run_agent/",
     "function": "run_agent",
     "params": [
                # required - one of "process_name" or "process_map" are required
                "process_name", "process_map",
                # optional
                "trusted_key", "text", "table_file",
                "image_file","source_file", "document_file"
                ],
     "response": ["agent_output"],
     "category": "agents",
     "timeout": 500},

    # ** get_db_info ** - returns information about the data stores available on the server
    # (available only on Model HQ API Server)

   {"api_name": "get_db_info",
    "methods": ["POST"],
    "endpoint": "/get_db_info/",
    "function": "get_db_info",
    "params": [
                # optional
                "trusted_key"
              ],
    "response": ["response"],
    "category": "server",
    "timeout": 3}

]

