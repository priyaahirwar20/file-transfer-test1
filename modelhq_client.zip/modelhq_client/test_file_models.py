
""" Tests for Model Inferencing and Generation APIs. """

from llmware_client_sdk import LLMWareClient

# my_endpoint = "http://44.198.29.51:8088"
# my_endpoint = "http://192.168.1.238:8088"
my_endpoint = "http://34.228.197.83:8088"

client = LLMWareClient(api_endpoint=my_endpoint)


def stream_example(prompt="What are the best sites to see in Shanghai?", model_name="phi-3-ov"):

    print("\nstream example\n")
    output = ""

    for token in client.stream(model_name=model_name,prompt=prompt, max_output=300, temperature=0.0, sample=False):
        print(token, end="")
        output += token

    return output


def inference_example(prompt="Who was the U.S. President in 1995?", model_name="phi-3-ov"):

    print("\ninference example\n")

    response = client.inference(prompt=prompt,model_name=model_name,temperature=0.0, sample=False)

    print("prompt: ", prompt)
    print("response: ", response)

    return response


def function_call_example(model_name="slim-sentiment-ov",context="That was the worst earnings call ever."):

    print("\nfunction call example\n")

    response = client.function_call(model_name=model_name, context=context)

    print("context: ", context)
    print("response: ", response)

    return response


def sentiment_function_call():

    """ Specialized inference method that provides a classification of the sentiment of an input text
    passage.  Example of specialized small function-calling models that can support and be integrated into
    agent-based processes. """

    input_passage = ("Those are the worst earnings that I can remember for a major company - they are in a lot of "
                     "trouble.")

    response = client.sentiment(context=input_passage)

    print("\nsentiment response: ", response)

    return response


def extract_function_call():

    """ Specialized inference method that provides a targeted extraction of information, based on keys
    provided in an 'extract_list' - returns a python dictionary with the values found corresponding to the
    requested keys. """

    extract_list = ["age", "name"]
    text = "Dwight was graduating college, and looking forward to starting to start working at age 22."

    response = client.extract(context=text, extract_keys=extract_list)

    print("\nextract response: ", response)

    return response


def generate_semantic_embeddings():

    """ Generates semantic embeddings from input text passages - these embeddings can be used for
    semantic similarity and insertion into a vector database for 'semantic search' and other RAG
    applications. """

    text = "It is a beautiful winter day in New York - cold but sunny - as we start our work day."
    text2 = "This is boring stuff about nothing."
    text3 = "This is a third example of an embedding text."

    text_list = [text, text2, text3]

    embedding = client.embedding(context=text_list)

    print("\nembedding response")
    for i, entry in enumerate(embedding["embeddings"]):
        print("-- generated embeddings - ", i, entry)

    return embedding


def classification_inference():

    """ Applies a specialized classification, useful for 'multi-model' agent processes and for
    applying safety guardrails. """

    # apply a model to test for bias
    text = "Sometimes I just meet someone that I don't like immediately for no reason."
    classification = client.classify(text, "valurank-bias-ov")

    print("\nclassification: ", classification)

    return classification


def semantic_ranker():

    """ Powerful technique to quickly identify semantic similarity among different passages in a document,
    or in multiple shorter documents/paragraphs. """

    doc1 = "Michael is studying physics at a university in Chicago right now."
    doc2 = "The weather is cold."
    doc3 = "I am going to see a basketball game this weekend - can't wait."

    query = "Who is Michael?"
    documents = [doc1, doc2, doc3]

    ranker = client.rank(query, documents)

    print("\nsemantic similarity ranker: ", ranker)

    return ranker


def vision_inference(prompt, img_path):

    """ Multimodal inference which takes as input a text prompt and the path to a local image, which is
    uploaded to the server.

    Please note that the processing of the image can take a few seconds, and then the generation answer
    is produced quickly.   """

    # need to set image path to local image
    import os

    if not os.path.exists(img_path):
        print(f"path to image not found - {img_path}")
        return None

    print("\nUploading Image - be patient for a few seconds.")

    response = client.vision(img_path, prompt)

    print("\nvision response: ", response)

    return response


def vision_stream_inference(prompt, img_path):

    """ Multimodal inference which takes as input a text prompt and the path to a local image, which is
    uploaded to the server.

    Please note that the processing of the image can take a few seconds, and then the generation answer
    is produced quickly.

    This example is identical to the 'vision_inference" example, except that it calls a generator
    function to stream the generated response token-by-token, which can be very helpful in some
    use cases.
    """

    # need to set image path to local image
    import os

    if not os.path.exists(img_path):
        print(f"path to image not found - {img_path}")
        return None

    print("\nUploading Image - be patient for a few seconds.")

    text_out = ""
    for token in client.vision_stream(img_path,prompt):
        print(token, end="")
        text_out += token

    print("\n\n")

    return text_out


def document_inference(document_file_path, question,
                       model_name="llama-3.2-1b-instruct-ov"):

    """ Input a document file path, which will be uploaded to the server, and then ask a
    question to the document.  Very small Llama 1b model selected by default - which will
    work reasonably well on simple queries and is good for testing -
    recommend to increase the model size to 3-7B parameters for more complex queries.
    """

    # note: the output response is a comprehensive dictionary with many keys
    # will output a lot to the screen

    response = client.document_inference(document_file_path, question, model_name=model_name)

    print("\ndocument inference response: ", response)

    return response


def document_batch_analysis(local_folder_path, query_list):

    """ This method is useful for analyzing batches of similar documents, such as contracts,
    and provides the ability to pass a local folder path with the documents, and a list of
    questions, and get a comparative analysis. """

    # doc analysis test
    print("\ndocument batch analysis example\n")

    response = client.document_batch_analysis(local_folder_path,query_list,use_async=False)

    print("response: ", response)
    for i, report in enumerate(response["output_report"]):
        print("report: ", i, report)

    return True


def core_model_tests():

    """ Runs series of model tests - can be run individually by commenting out specific items. """

    stream_example()
    inference_example()
    function_call_example()
    sentiment_function_call()
    extract_function_call()
    generate_semantic_embeddings()
    semantic_ranker()
    classification_inference()

    # this points to the test image included in the client_sdk_10041 package
    # -> may need to adjust img_path
    img_path = ".\\sample_files\\mountain.jpeg"
    vision_inference("Describe this image.", img_path)
    vision_stream_inference("Describe this image.", img_path)

    # document inference uses included sample document as example
    doc_path = ".\\sample_files\\Bia EXECUTIVE EMPLOYMENT AGREEMENT.pdf"
    question = "What are the terms of the sale bonus?"
    document_inference(doc_path, question)

    # document batch analysis
    query_list = ["What is the annual rate of the base salary?",
                  "When is the effective date of the agreement?"]
    agreements_fp = ".\\sample_files\\Agreements"
    document_batch_analysis(agreements_fp, query_list)

    return True


if __name__ == "__main__":
    core_model_tests()

