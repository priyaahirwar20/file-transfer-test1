
""" LLMWare Client library that wraps POST request calls to simplify accessing APIs. """

import requests
import json
import logging
import os
import psutil
from modelhq_client.api_service_catalog import api_catalog

logger = logging.getLogger("llmware_log")


class LLMWareClient:

    """ Client interface into APIs provided in the api_catalog for the Models module. """

    def __init__(self, api_endpoint=None, api_key=None, account_id=None, library_name=None,
                 api_custom_catalog=None,timeout=20):

        self.URL_BASE = api_endpoint
        self.api_key = api_key
        self.account_id = account_id
        self.library_name = library_name
        self.timeout = timeout

        if api_custom_catalog:
            self.api_catalog = api_custom_catalog
        else:
            self.api_catalog = api_catalog

    def package_url_base(self, ip_address=None, port=None, http_type="http",endpoint_dict=None):

        """ Utility to package url base from an endpoint description of components, e.g.,

            endpoint = { "api_server": "xeon_1123_3",
                         "ip_address": "3.83.100.23",
                         "port": "8088",
                         "secret_key": "flying-soup",
                         "http_type": "HTTP"
                        }
        """

        if endpoint_dict and not ip_address and not port:
            if isinstance(endpoint_dict,dict):
                ip_address = endpoint_dict.get("ip_address", None)
                port = endpoint_dict.get("port", None)
                http_type = endpoint_dict.get("http_type", None)

        http_type = str(http_type).lower() + "://"

        self.URL_BASE = http_type + str(ip_address) + ":" + str(port)

        return self.URL_BASE

    def _lookup_endpoint(self, api_name):

        """ Internal lookup utility to pull api card. """

        for entries in self.api_catalog:
            if entries["api_name"] == api_name:
                return entries

        return {}

    def _exec_standard_api(self, api_name, timeout=None, **kwargs):

        """ Internal helper method to execute on common pattern APIs. """

        api = self._lookup_endpoint(api_name)

        endpoint = api["endpoint"]
        params = api["params"]

        if "timeout" in api:
            timeout = api["timeout"]

        input_dict = {}

        for k, v in kwargs.items():
            if k in params:
                input_dict.update({k: v})

        if not timeout:
            timeout = self.timeout

        url = self.URL_BASE + "{}".format(endpoint)

        try:
            output_raw = requests.post(url, data=input_dict, timeout=timeout)
            output = json.loads(output_raw.text)
        except Exception as e:
            logger.warning(f"Unable to execute api request - {api_name} - caught exception - {e}")
            output = {}

        return output

    def inference(self, **kwargs):

        """ Main method for executing an inference with a model. Response will be provided upon the
        completion of the generation. Requires input of model_name and prompt with several optional
        parameters to control generation output. """

        api_name = "inference"
        api = self._lookup_endpoint(api_name)

        endpoint = api["endpoint"]
        params = api["params"]
        inp = {}
        for k,v in kwargs.items():
            if k in params:
                inp.update({k:v})

        url = self.URL_BASE + "{}".format(endpoint)
        output_raw = requests.post(url, data=inp)
        output = json.loads(output_raw.text)

        return output

    def stream(self, **kwargs):

        """ Main method for streamed inference generation, most useful for chat and real-time
        interaction with a model generation.

        This method is intended to be consumed as a generator function, e.g.,

            for token in client.stream('What is ...?', model_name='phi-3-ov'):
                print(token, end="")

        """

        api_name = "stream"
        api = self._lookup_endpoint(api_name)

        endpoint = api["endpoint"]
        params = api["params"]
        inp = {}
        for k, v in kwargs.items():
            if k in params:
                inp.update({k: v})

        url = self.URL_BASE + "{}".format(endpoint)
        r = requests.post(url=url, data=inp, stream=True)

        output = ""

        for tokens in r.iter_content(chunk_size=32):
            if tokens:
                # need to check encoding option
                new_out = str(tokens, encoding='utf-8',errors='ignore')
                output += new_out
                yield new_out

        response = {"llm_response": output}

        return response

    def function_call(self, **kwargs):

        """ Specialized model inferencing designed for SLIM function calling models with input of context,
        function and parameters, and an output that is a well-formed python object, e.g., dictionary, list,
        SQL statement. """

        api_name = "function_call"
        api = self._lookup_endpoint(api_name)

        endpoint = api["endpoint"]
        params = api["params"]
        inp = {}

        for k, v in kwargs.items():
            if k in params:
                inp.update({k: v})

        url = self.URL_BASE + "{}".format(endpoint)
        output_raw = requests.post(url, data=inp)
        output = json.loads(output_raw.text)

        return output

    def sentiment (self, **kwargs):

        """ Specialized common function call to evaluate an input context passage and provide a
        classification of the sentiment and confidence level. """

        api_name = "sentiment"
        api = self._lookup_endpoint(api_name)

        endpoint = api["endpoint"]
        params = api["params"]
        inp = {}

        for k, v in kwargs.items():
            if k in params:
                inp.update({k: v})

        url = self.URL_BASE + "{}".format(endpoint)
        output_raw = requests.post(url, data=inp)
        output = json.loads(output_raw.text)

        return output

    def extract (self, **kwargs):

        """ Specialized model inference with 'extract' model that takes as input a context passage,
        a list of extract keys, and returns a python dictionary with each of the keys and the values, if any,
        found in the passage. """

        api_name = "extract"
        api = self._lookup_endpoint(api_name)

        endpoint = api["endpoint"]
        params = api["params"]
        inp = {}

        for k, v in kwargs.items():
            if k in params:
                inp.update({k: v})

        url = self.URL_BASE + "{}".format(endpoint)
        output_raw = requests.post(url, data=inp)
        output = json.loads(output_raw.text)

        return output

    def vision(self, image_fp, prompt, **kwargs):

        """ Multimodal 'vision' model call that takes as input a path to a local image (jpeg or png)
        and a prompt or question - and then returns a text answer as output.

        If no model provided, then the inference server will use a default vision model (which is a
        configurable parameter).

        This method returns a response upon completion of the generation, and is designed for batch or
        non-real time processing.
        """

        api_name = "vision"

        api = self._lookup_endpoint(api_name)

        endpoint = api["endpoint"]
        params = api["params"]

        inp = {}
        inp.update({"prompt": prompt})

        file_list = []
        fn = image_fp.split("/")[-1]
        new_entry = ('uploaded_files', (fn, open(image_fp,'rb')))
        file_list.append(new_entry)

        url = self.URL_BASE + "{}".format(endpoint)
        output_raw = requests.post(url, data=inp,files=file_list)
        output = json.loads(output_raw.text)

        return output

    def vision_stream(self, image_fp, prompt, **kwargs):

        """ Multimodal 'vision' model call that takes as input a path to a local image (jpeg or png)
        and a prompt or question - and then returns a text answer as output.

        If no model provided, then the inference server will use a default vision model (which is a
        configurable parameter).

        This method returns a streaming response and is intended to be consumed as a generator function,
        e.g.,

        for token in model.stream("What is ...", img):
            print(token, end="")

        Please note that there may be an initial delay of 10-15 seconds while the model is processing and
        encoding the image content, and then generation streaming will be very fast after that.

        """

        api_name = "vision_stream"

        api = self._lookup_endpoint(api_name)

        endpoint = api["endpoint"]
        params = api["params"]

        inp = {}
        inp.update({"prompt": prompt})

        # for k, v in kwargs.items():
        #    if k in params:
        #        inp.update({k: v})

        file_list = []
        fn = image_fp.split("/")[-1]
        new_entry = ('uploaded_files', (fn, open(image_fp,'rb')))
        file_list.append(new_entry)

        url = self.URL_BASE + "{}".format(endpoint)
        r = requests.post(url=url, data=inp, files=file_list,stream=True)

        output = ""

        for tokens in r.iter_content(chunk_size=32):
            if tokens:
                new_out = str(tokens, encoding='utf-8',errors='ignore')
                # print(new_out, end="")
                output += new_out
                yield new_out

        response = {"llm_response": output}

        return response

    def library_inference(self, library_name, question, model_name="", trusted_key=None,
                          use_top_n_context=5, **kwargs):

        """ Executes a basic 'RAG' inference with the knowledge source as a pre-existing Library
        on the server.   This method combines several common atomic steps into a single operation:

        1. Connects to the library - note: library must have already been created.
        2. Executes a semantic query on the library based on the input question.
        3. Builds a set of ranked results from the library.
        4. Creates a best-fit 'Context' passage from the ranked results.
        5. Prompts the selected model with the knowledge context and question to generate the answer.
        """

        api_name = "library_inference"

        api = self._lookup_endpoint(api_name)

        endpoint = api["endpoint"]
        params = api["params"]
        inp = {}
        inp.update({"library_name": library_name})
        inp.update({"question": question})
        if model_name:
            inp.update({"model_name": model_name})

        if use_top_n_context:
            inp.update({"use_top_n_context": use_top_n_context})

        inp.update({"trusted_key": trusted_key})

        for k, v in kwargs.items():
            if k in params:
                inp.update({k: v})

        url = self.URL_BASE + "{}".format(endpoint)
        output_raw = requests.post(url, data=inp)
        output = json.loads(output_raw.text)

        return output

    def document_inference(self, document_path, question, model_name="",
                           text_chunk_size=None, tables_only=False,
                           use_top_n_context=None, trusted_key=None, **kwargs):

        """ Executes a basic 'RAG' inference on one specific local document.  No advance preparation
        is required.   This method combines several common atomic steps into a single operation:

        1. Uploads the document from the local folder path.
        2. Parses, text chunks and indexes the document.
        3. Runs an in-memory semantic similarity ranking to identify the most relevant parts of the document.
        4. Creates a best-fit 'Context' passage from the ranked results.
        5. Prompts the selected model with the knowledge context and question to generate the answer.
        """

        import os

        api_name = "document_inference"

        api = self._lookup_endpoint(api_name)

        endpoint = api["endpoint"]
        params = api["params"]
        inp = {}
        inp.update({"question": question})
        if model_name:
            inp.update({"model_name": model_name})
        if text_chunk_size:
            inp.update({"text_chunk_size": text_chunk_size})
        if tables_only:
            inp.update({"tables_only": tables_only})
        if use_top_n_context:
            inp.update({"use_top_n_context": use_top_n_context})

        inp.update({"trusted_key": trusted_key})

        for k, v in kwargs.items():
            if k in params:
                inp.update({k: v})

        # need to prepare file input
        file_list = []
        fn = document_path.split(os.sep)[-1]
        new_entry = ("uploaded_document", (fn,open(document_path,'rb')))
        file_list.append(new_entry)

        url = self.URL_BASE + "{}".format(endpoint)
        output_raw = requests.post(url, data=inp, files=file_list)
        output = json.loads(output_raw.text)

        return output

    def ping(self, **kwargs):

        """ Utility method to quickly check if api server is responsive - useful for testing as well as
        situations in which the server may be 'loosely coupled' to a client machine which can also operate
        independently of the API. """

        api_name = "ping"
        return self._exec_standard_api(api_name,**kwargs)

    def server_stop(self, **kwargs):

        api_name = "server_stop"

        api = self._lookup_endpoint(api_name)

        endpoint = api["endpoint"]
        params = api["params"]
        timeout = self.timeout

        if "timeout" in api:
            timeout = api["timeout"]

        input_dict = {}

        for k, v in kwargs.items():
            if k in params:
                input_dict.update({k: v})

        url = self.URL_BASE + "{}".format(endpoint)

        # try:
        output_raw = requests.post(url, data=input_dict, timeout=timeout)
        output = json.loads(output_raw.text)
        print("output - ", output)
        # except Exception as e:

        #    logger.warning(f"Unable to execute api request - {api_name} - caught exception - {e}")
        #    output = {}

        return self._exec_standard_api(api_name,**kwargs)

    def get_api_catalog(self, **kwargs):

        """ Utility method that returns a list of all of the APIs supported by the API server. """

        api_name = "get_api_catalog"
        return self._exec_standard_api(api_name, **kwargs)

    def embedding(self, context, model_name="", **kwargs):

        """ Embedding API takes a list of one or more context passages as input, and returns a list of
        embedding vectors, corresponding to each input provided.   The dimensionality of the output vectors
        will depend upon the embedding model selected, but will be generally between 384 - 1536 dimensions.

        These vectors can used either 'ad hc' in memory for the on-the-fly vector search, or taken in batch
        and inserted into a vector database.
        """

        api_name = "embedding"
        api = self._lookup_endpoint(api_name)

        endpoint = api["endpoint"]
        params = api["params"]
        inp = {}
        inp.update({"context": context})
        inp.update({"model_name": model_name})

        for k,v in kwargs.items():
            if k in params:
                inp.update({k:v})

        url = self.URL_BASE + "{}".format(endpoint)
        output_raw = requests.post(url, data=inp)
        output = json.loads(output_raw.text)

        return output

    def classify(self, context, model_name, **kwargs):

        """ Classify method applies a specialized classifier method to a context passage and returns the
        classification as output.

        Note: the model must be a classifier model that supports a classify method.

        The current model catalog provides classifiers primarily for guardrail functions, e.g., prompt injection or
        bias detection.
        """

        api_name = "classify"
        api = self._lookup_endpoint(api_name)

        endpoint = api["endpoint"]
        params = api["params"]
        inp = {}
        inp.update({"context": context})
        inp.update({"model_name": model_name})

        for k, v in kwargs.items():
            if k in params:
                inp.update({k: v})

        url = self.URL_BASE + "{}".format(endpoint)
        output_raw = requests.post(url, data=inp)
        output = json.loads(output_raw.text)

        return output

    def rank(self, query, documents, **kwargs):

        """ Specialized semantic 'ranking' function provided by Reranker models.  The input is a query or input
        passage, and a list of documents (e.g., text chunks, typically a paragraph or two in length), and
        the model will return the semantic similarity 'ranked' or each of the documents with the target
        query passage.  This is an effective RAG technique especially when a vector database is not
        available or the scope of documents is relatively small. """

        api_name = "rank"
        api = self._lookup_endpoint(api_name)

        endpoint = api["endpoint"]
        params = api["params"]
        inp = {}
        inp.update({"query": query})
        inp.update({"documents": documents})

        for k, v in kwargs.items():
             if k in params:
                inp.update({k: v})

        url = self.URL_BASE + "{}".format(endpoint)
        output_raw = requests.post(url, data=inp)
        output = json.loads(output_raw.text)

        return output

    def list_all_models(self, **kwargs):

        """ Returns all of the models available in the Model Catalog accessible to the API server. """

        api_name = "list_all_models"
        return self._exec_standard_api(api_name, **kwargs)

    def system_info(self, **kwargs):

        """ Utility function that returns key system information about the machine where the server is
        running, including current state of CPU and memory utilization and the number of models currently
        in memory. """

        api_name = "system_info"
        return self._exec_standard_api(api_name, **kwargs)

    def model_lookup(self, model_name, **kwargs):

        """ Lookup full model card information for a selected model name. Quick and easy way to discover a
        model and/or confirm that the model is available on the machine. """

        api_name = "model_lookup"
        kwargs.update({"model_name": model_name})
        return self._exec_standard_api(api_name, **kwargs)

    def model_load(self, model_name, **kwargs):

        """ Explicitly loads a selected model into memory on the API server, useful as a preparation
        step. """

        api_name = "model_load"
        kwargs.update({"model_name": model_name})
        return self._exec_standard_api(api_name, **kwargs)

    def model_unload(self, model_name, **kwargs):

        """ Explicitly unloads a selected model from memory on the API server. """

        api_name = "model_unload"
        kwargs.update({"model_name": model_name})
        return self._exec_standard_api(api_name, **kwargs)

    def create_new_library(self, **kwargs):

        """ Creates a new library which is a collection of documents that are parsed, indexed and
        organized. """

        api_name = "create_new_library"
        api = self._lookup_endpoint(api_name)

        endpoint = api["endpoint"]
        params = api["params"]
        inp = {}

        for k, v in kwargs.items():
            if k in params:
                inp.update({k: v})

        url = self.URL_BASE + "{}".format(endpoint)
        output_raw = requests.post(url, data=inp)
        output = json.loads(output_raw.text)

        return output

    def add_files(self, library_name, local_folder_path, use_async=False, **kwargs):

        """ Core method of adding files to a Library, which are parsed, text chunked and indexed
        automatically upon upload. """

        import os

        if use_async:
            api_name = "add_files_async"
        else:
            api_name = "add_files"

        api = self._lookup_endpoint(api_name)

        endpoint = api["endpoint"]
        params = api["params"]
        inp = {}
        inp.update({"library_name": library_name})

        for k, v in kwargs.items():
            if k in params:
                inp.update({k: v})

        # need to prepare file input
        files = os.listdir(local_folder_path)
        file_list = []
        for f in list(files):
            fp = os.path.join(local_folder_path, f)
            new_entry = ('uploaded_files', (f, open(fp,'rb')))
            file_list.append(new_entry)

        url = self.URL_BASE + "{}".format(endpoint)
        output_raw = requests.post(url, data=inp,files=file_list)
        output = json.loads(output_raw.text)

        return output

    def query(self, library_name, user_query, **kwargs):

        """ Execute a query against an existing library. """

        api_name = "query"
        api = self._lookup_endpoint(api_name)

        endpoint = api["endpoint"]
        params = api["params"]
        inp = {}
        inp.update({"library_name": library_name})
        inp.update({"user_query": user_query})

        for k, v in kwargs.items():
            if k in params:
                inp.update({k: v})

        url = self.URL_BASE + "{}".format(endpoint)
        output_raw = requests.post(url, data=inp)
        output = json.loads(output_raw.text)

        return output

    def get_library_card(self, **kwargs):

        """ Get metadata information about a library. """

        api_name = "get_library_card"
        # kwargs.update({"library_name": lib_name})
        return self._exec_standard_api(api_name,**kwargs)

    def install_embedding(self,lib_name, use_async=False, **kwargs):

        """ Expects a pre-existing library with documents already added.   This method installs
        an embedding across the library and creates the appropriate vectors in the vector database
        for the library collection. """

        if use_async:
            api_name = "install_embedding_async"
        else:
            api_name = "install_embedding"

        kwargs.update({"library_name": lib_name})
        return self._exec_standard_api(api_name,**kwargs)

    def semantic_query(self,lib_name, input_query,**kwargs):

        """ Executes a semantic / vector query against embeddings already created. """

        api_name = "semantic_query"
        kwargs.update({"library_name": lib_name})
        kwargs.update({"user_query": input_query})

        #TODO: need to better handle these defaults

        if "db" not in kwargs:
            kwargs.update({"db": "mongo"})

        if "vector_db" not in kwargs:
            kwargs.update({"vector_db": "milvus"})

        return self._exec_standard_api(api_name, **kwargs)

    def document_batch_analysis(self, local_folder_path, question_list, use_async=False, **kwargs):

        """ Specialized RAG method that takes a set of documents from a local folder path, and a
        question list, and then analyzes the batch of documents and provides answers to each of the
        questions.  Intended for use with repetitive structured documents, e.g., contracts or invoices
        in which the same set of questions is asked to all of the documents, such as:

        'What is the governing law?'
        'When is the invoicing date?'
        'What is the termination for cause notice period?'

        This method does not require any previous setup of a library or knowledge base, and performs all of
        the steps 'on the fly' with the files and questions provided.

        Please note that it can take a little time, depending upon the number of documents and questions.

        """

        import os

        if use_async:
            api_name = "document_batch_analysis_async"
        else:
            api_name = "document_batch_analysis"

        api = self._lookup_endpoint(api_name)

        endpoint = api["endpoint"]
        params = api["params"]
        inp = {}
        inp.update({"question_list": question_list})

        for k, v in kwargs.items():
            if k in params:
                inp.update({k: v})

        # need to prepare file input
        files = os.listdir(local_folder_path)
        file_list = []
        for f in list(files):
            fp = os.path.join(local_folder_path, f)
            new_entry = ('uploaded_files', (f, open(fp,'rb'))) # ,'image/png'))
            file_list.append(new_entry)

        inp.update({"reranker": "jina-reranker-v1-tiny-en-ov"})
        url = self.URL_BASE + "{}".format(endpoint)
        output_raw = requests.post(url, data=inp,files=file_list)
        output = json.loads(output_raw.text)

        return output

    def get_document_list(self, library_name="", **kwargs):

        """ Returns a list of documents contained in a library. """

        api_name = "get_document_list"
        kwargs.update({"library_name": library_name})

        return self._exec_standard_api(api_name, **kwargs)

    def get_document_text(self, library_name="", doc_id="", doc_fn="", **kwargs):

        """ Returns a text extract of a selected document from a selected library. """

        api_name = "get_document_text"
        kwargs.update({"library_name": library_name})
        kwargs.update({"doc_id": doc_id})
        kwargs.update({"doc_fn": doc_fn})

        return self._exec_standard_api(api_name, **kwargs)

    def get_db_info(self, **kwargs):

        """ Utility function that returns the registered db and vector db available on the server -
        can be more than one option provided. """

        api_name = "get_db_info"
        return self._exec_standard_api(api_name, **kwargs)

    def lookup_agent(self, process_name, trusted_key="", **kwargs):

        """ Checks if an agent process can be located on the server. """

        api_name = "lookup_agent"

        api = self._lookup_endpoint(api_name)

        endpoint = api["endpoint"]
        params = api["params"]
        inp = {}
        inp.update({"process_name": process_name})
        inp.update({"trusted_key": trusted_key})

        return self._exec_standard_api(api_name, **inp)

    def get_all_agents(self, trusted_key=""):

        api_name = "get_all_agents"
        api = self._lookup_endpoint(api_name)

        endpoint = api["endpoint"]
        params = api["params"]
        inp = {}
        inp.update({"trusted_key": trusted_key})

        return self._exec_standard_api(api_name, **inp)


    def run_agent(self, process_name="", process_zip_path="", input_list=None, trusted_key="",
                  text="", doc_file_path="", table_file_path="", image_file_path="", source_file_path="",
                  snippet="", **kwargs):

        """ Executes an agent process. """

        #TODO: needs option to run an existing process without uploading/installing process_zip

        api_name = "run_agent"
        api = self._lookup_endpoint(api_name)

        endpoint = api["endpoint"]
        params = api["params"]
        inp = {}
        inp.update({"process_name": process_name})
        inp.update({"trusted_key": trusted_key})
        inp.update({"text": text})
        inp.update({"snippet": snippet})

        if not process_name and not process_zip_path:
            logger.info(f"LLMWareAgentClient - install_agent - could not identify process agent - "
                        f"{process_name}")
            return {}

        # for k, v in kwargs.items():
        #    if k in params:
        #        inp.update({k: v})

        # need to prepare file input
        upload_files = []
        if process_zip_path:
            new_entry = ('process_zip', (process_name, open(process_zip_path,'rb')))
            upload_files.append(new_entry)

        updated_input_list = []

        if input_list:
            upload_user_inputs = []
            for entry in input_list:

                input_name = entry[0]
                input_type = entry[1]
                input_value = entry[2]

                if input_type in ["collection"]:
                    # need to unpack and save each file in the collection
                    # input_value should be a list
                    if isinstance(input_value,list):
                        for file in input_value:
                            fn = str(file).split(os.sep)[-1]
                            upload_entry = ("user_files", (fn, open(file, 'rb')))
                            upload_files.append(upload_entry)
                            updated_input_list.append(input_name)
                            updated_input_list.append(input_type)
                            updated_input_list.append(fn)

                elif input_type not in ["text", "snippet"]:

                    # interpret input value as file path
                    input_value_local_fp = input_value
                    fn = str(input_value_local_fp).split(os.sep)[-1]

                    # upload_entry = ('uploaded_files', (fn, open(input_value_local_fp, 'rb')))
                    upload_entry = ("user_files", (fn, open(input_value_local_fp, 'rb')))
                    # upload_user_inputs.append(upload_entry)
                    upload_files.append(upload_entry)

                    # for input list, will keep only filename
                    new_input_entry = [input_name, input_type, fn]
                    updated_input_list.append(input_name)
                    updated_input_list.append(input_type)
                    updated_input_list.append(fn)

                else:
                    updated_input_list.append(input_name)
                    updated_input_list.append(input_type)
                    updated_input_list.append(input_value)

            # will use to sort the files when received
            inp.update({"input_list": updated_input_list})

        if table_file_path:
            fn = str(table_file_path).split(os.sep)[-1]
            new_entry = ('table_file', (fn, open(table_file_path,'rb')))
            upload_files.append(new_entry)
        if image_file_path:
            fn = str(image_file_path).split(os.sep)[-1]
            new_entry = ('image_file', (fn, open(image_file_path, 'rb')))
            upload_files.append(new_entry)
        if doc_file_path:
            fn = str(doc_file_path).split(os.sep)[-1]
            new_entry = ('document_file', (fn, open(doc_file_path, 'rb')))
            upload_files.append(new_entry)
        if source_file_path:
            fn = str(source_file_path).split(os.sep)[-1]
            new_entry = ('source_file', (fn, open(source_file_path, 'rb')))
            upload_files.append(new_entry)

        url = self.URL_BASE + "{}".format(endpoint)

        # print("--test: run_agent - ", inp)

        output_raw = requests.post(url, data=inp,files=upload_files)
        try:
            output = json.loads(output_raw.text)
        except:
            output = {}

        return output

    def run_agent_dep_10107(self, process_name="", process_zip_path="", trusted_key="",
                  text="",
                  doc_file_path="",
                  table_file_path="",
                  image_file_path="",
                  source_file_path="",
                  snippet="",
                  **kwargs):

        """ Executes an agent process. """

        #TODO: needs option to run an existing process without uploading/installing process_zip

        api_name = "run_agent"
        api = self._lookup_endpoint(api_name)

        endpoint = api["endpoint"]
        params = api["params"]
        inp = {}
        inp.update({"process_name": process_name})
        inp.update({"trusted_key": trusted_key})
        inp.update({"text": text})
        inp.update({"snippet": snippet})

        if not process_name and not process_zip_path:
            logger.info(f"LLMWareAgentClient - install_agent - could not identify process agent - "
                       f"{process_name}")
            return {}

        # for k, v in kwargs.items():
        #    if k in params:
        #        inp.update({k: v})

        # need to prepare file input
        upload_files = []
        if process_zip_path:
            new_entry = ('process_zip', (process_name, open(process_zip_path,'rb')))
            upload_files.append(new_entry)
        if table_file_path:
            fn = str(table_file_path).split(os.sep)[-1]
            new_entry = ('table_file', (fn, open(table_file_path,'rb')))
            upload_files.append(new_entry)
        if image_file_path:
            fn = str(image_file_path).split(os.sep)[-1]
            new_entry = ('image_file', (fn, open(image_file_path, 'rb')))
            upload_files.append(new_entry)
        if doc_file_path:
            fn = str(doc_file_path).split(os.sep)[-1]
            new_entry = ('document_file', (fn, open(doc_file_path, 'rb')))
            upload_files.append(new_entry)
        if source_file_path:
            fn = str(source_file_path).split(os.sep)[-1]
            new_entry = ('source_file', (fn, open(source_file_path, 'rb')))
            upload_files.append(new_entry)

        url = self.URL_BASE + "{}".format(endpoint)
        output_raw = requests.post(url, data=inp,files=upload_files)
        try:
            output = json.loads(output_raw.text)
        except:
            output = {}

        return output


def check_if_background_running():

    app_path = os.environ.get("USERPROFILE") + os.sep + "llmware_data" + os.sep + "app" + os.sep
    backend_start_record_fn = "backend_start_records.txt"

    # check start log file
    start_log_fp = os.path.join(app_path, backend_start_record_fn)
    if not os.path.exists(start_log_fp):
        return None
    else:
        # need to return the PID of the running process
        start_log = open(start_log_fp, "r").read()
        pid_meta = start_log.split("\n")
        pid = int(pid_meta[0])
        pid_status = pid_meta[1]
        pid_name = pid_meta[2]
        pid_exe = pid_meta[3]

        print(f"--test: start_log - {start_log} - pid_meta - {pid_meta}")

        # check if pid active
        import psutil
        p = psutil.Process(pid)
        status = p.status()
        name = p.name()
        if pid_name == name:
            # confirmed name matches - pid is active
            print("--test: found matching process on system - ", pid_name, name)
        else:
            # if old record, then skip
            pass

        return pid


def _stop_server():

    """ Stops server based on server start record. """

    import time
    import psutil

    app_path = os.environ.get("USERPROFILE") + os.sep + "llmware_data" + os.sep + "app" + os.sep
    backend_start_record_fn = "backend_start_records.txt"

    # check start log file
    start_log_fp = os.path.join(app_path, backend_start_record_fn)
    if not os.path.exists(start_log_fp):
        return None
    else:
        # need to return the PID of the running process
        start_log = open(start_log_fp, "r").read()
        pid = int(start_log.split("\n")[0])

        try:
            p = psutil.Process(pid)
            p.terminate()  # or p.kill()
            # os.kill(thread_pid, signal.CTRL_C_EVENT)
            # os.kill(thread_pid, signal.SIGTERM)
            logger.info(f"Closed API server.")
            os.remove(start_log_fp)
            logger.info(f"Deleted active start log record.")
        except:
            logger.warning(f"Failed to terminate process - {pid}")

    return True


def stop_server():

    confirmation = check_if_background_running()

    if confirmation:
        stop_confirm = _stop_server()
        print("done - stopped_server - ", stop_confirm)

    return True


def get_url_string():

    url_str = ""

    server_details = get_server_details()
    if server_details:
        if "ip_address" in server_details:
            url_str = server_details["ip_address"]

    return url_str


def get_server_details():

    import psutil

    #TODO: safety check if called on Linux
    app_path = os.environ.get("USERPROFILE") + os.sep + "llmware_data" + os.sep + "app" + os.sep
    backend_start_record_fn = "backend_start_records.txt"

    server_details = {}

    # check start log file
    start_log_fp = os.path.join(app_path, backend_start_record_fn)
    if not os.path.exists(start_log_fp):
        return server_details
    else:
        # need to return the PID of the running process
        start_log = open(start_log_fp, "r").read()
        pid_meta = start_log.split("\n")

        pid = None
        pid_name = ""
        pid_exe = ""
        time_stamp = ""
        ip_address = ""

        if len(pid_meta) >= 1:
            pid = int(pid_meta[0])
            server_details.update({"process_id": pid})

        if len(pid_meta) >= 6:

            status = pid_meta[1]
            pid_name = pid_meta[2]
            pid_exe = pid_meta[3]
            time_stamp = pid_meta[4]
            ip_address = pid_meta[5]

            server_details.update({"process_name": pid_name})
            server_details.update({"process_exe": pid_exe})
            server_details.update({"time_started": time_stamp})
            server_details.update({"ip_address": ip_address})

        # check if pid active
        if pid:
            p = psutil.Process(pid)
            if p:
                status = p.status()
                name = p.name()
                if pid_name == name:
                    # confirmed name matches - pid is active
                    # go ahead case
                    server_details.update({"status": "running"})
                else:
                    # if old record, then delete
                    server_details.update({"status": "unconfirmed - process may not be active"})

    return server_details
