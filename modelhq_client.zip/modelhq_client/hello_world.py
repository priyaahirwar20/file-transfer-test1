
""" Hello World example """

import time

from llmware_client_sdk import LLMWareClient, get_url_string

api_endpoint = get_url_string()

client = LLMWareClient(api_endpoint=api_endpoint)

# main streaming api - enter prompt and model name

prompt = "What are the best sites to see in France?"

model_name = "llama-3.2-1b-instruct-ov"

# a few good small models to start getting familiar with the api
#   -- llama-3.2-1b-instruct-ov
#   -- llama-3.2-3b-instruct-ov
#   -- phi-3-ov
#   -- mistral-7b-instruct-v0.3-ov
#   -- phi-4-ov

print("\nStarting 'Hello World'")
print(f"Prompt: {prompt}")
print(f"Model: {model_name}\n")

t0 = time.time()

count = 0

response = client.inference(prompt=prompt,model_name=model_name, max_output=100)

print("\ninference response: ", response)

print("\nstream response ...\n")

for token in client.stream(prompt=prompt,
                           model_name=model_name,max_output=1000):
    print(token,end="")

t1 = time.time()

print("\n\ntotal time - ", t1-t0)

# optional - unloads the model from memory
client.model_unload(model_name)
