

""" A few examples to get started. See the documentation for more, or look at the api_service_catalog.py
    file included with these materials which provides direct overview of each of the supported APIs. """

import os
from modelhq_client import LLMWareClient, get_server_details, stop_server, get_url_string

# endpoint can usually be determined automatically using get_url_string()
# alternatively, it will be displayed at the time of launching the backend server
# it will usually correspond explicitly to:  "http://localhost:8088" and/or external IP of device

# my_endpoint = "http://localhost:8088"

my_endpoint = get_url_string()

# alt: on api server
# my_endpoint = "http://13.222.11.192:8088"

print("auto detected get_url_string - ", my_endpoint)

client = LLMWareClient(api_endpoint=my_endpoint)

# show all agents available on the background server

print("\n\nCheck for Available Agents")

agent_response = client.get_all_agents()
for i, agent in enumerate(agent_response["response"]):
    print("--agents available: ", i, agent)

# run agent process - uses sample file included in the development kit
# alternatively, you could pass another file, or direct text string, e.g., text = "..."

print("\n\nRun Agent example as API")
process_name = "speech_gen"
text = "I am tired of reading everything so please just tell me!"

response = client.run_agent(process_name = process_name,
                            input_list=[("MAIN-INPUT", "text", text)])


print("response: ", response)

process_name = "intake_processing"
fp = os.path.abspath(".\\modelhq_client\\sample_files\\customer_transcript_1.txt")
text = open(fp, "r").read()

# response = client.run_agent(process_name=process_name,
#                             input_list=[("MAIN-INPUT", "text", text)], trusted_key="")
# print("--run_agent intake_processing: ", response)

